from django.core.validators import RegexValidator
from django.db import models
from django.urls import reverse
from django.utils import timezone

from apps.corecode.models import StudentClass


class Student(models.Model):
    STATUS_CHOICES = [("active", "Active"), ("inactive", "Inactive")]

    GENDER_CHOICES = [("male", "Male"), ("female", "Female")]
    section = [("a","A"),("b","B"),("c","C")]
    P_class = [("Nursery","Nursery"),("KG","KG"),("1st","1st"),("2nd","2nd"),("3rd","3rd"),("4th","4th"),("5th","5th"),("6th","6th"),("7th","7th"),("8th","8th"),("9th","9th"),("10th","10th")]

    current_status = models.CharField(
        max_length=10, choices=STATUS_CHOICES, default="active"
    )
    GR_number = models.CharField(max_length=200, unique=True)
    

    firstname = models.CharField(max_length=200)
    Father_Name = models.CharField(max_length=200,null=True)
    Father_CNIC = models.CharField(max_length=200,null=True)
    surname = models.CharField(max_length=200)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default="male")
    date_of_birth = models.DateField(default=timezone.now)
    Birthofplace = models.CharField(max_length=200,null=True)
    Father_Occupation = models.CharField(max_length=200,null=True)
    Previous_School = models.CharField(max_length=200,null=True)
    
    Previous_class =models.CharField(max_length=10, choices=P_class, null=True)
    current_class = models.ForeignKey(
        StudentClass, on_delete=models.SET_NULL, blank=True, null=True
    )
    section = models.CharField(max_length=10, choices=section, null=True)
    Religion = models.CharField(max_length=200,null=True)
    Language = models.CharField(max_length=200,null=True)
    date_of_admission = models.DateField(default=timezone.now)

    mobile_num_regex = RegexValidator(
        regex="^[0-9]{10,15}$", message="Entered mobile number isn't in a right format!"
    )
    parent_mobile_number = models.CharField(
        validators=[mobile_num_regex], max_length=13, blank=True
    )

    address = models.TextField(blank=True)
    others = models.TextField(blank=True)
    admission_fees = models.CharField(max_length=200 ,null=True)
    passport = models.ImageField(blank=True, upload_to="students/passports/")

    class Meta:
        ordering = ["firstname", "Father_Name"]

    def __str__(self):
        return f"{self.firstname}  ({self.GR_number})"

    def get_absolute_url(self):
        return reverse("student-detail", kwargs={"pk": self.pk})


class StudentBulkUpload(models.Model):
    date_uploaded = models.DateTimeField(auto_now=True)
    csv_file = models.FileField(upload_to="students/bulkupload/")



    